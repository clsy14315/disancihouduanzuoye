package main

import (
	"fmt"

)
var chs = make (chan int ,20)
var myres = make(map[int]int, 20)
var s = make(chan int,20)

var receive int
func factorial (n int) {
	var res int = 1
	for i := 1; i <= n; i ++ {
		res *= i

	}

	chs<-res
	receive = <- chs
	myres[n]=receive
}

func main() {
	for i := 1; i <= 20 ; i ++ {
		go factorial(i)

	}
	//	for _, v := range receive {
	//fmt.Println(receive)
	//}
	for _, v := range myres {
		fmt.Println(v)
	}

}
